"""
reanalyse.py — Re-analyse a previously saved flight search without re-running it.

Usage (from FlightFinderFriends.py):
    python FlightFinderFriends.py --reanalyse "003"
    python FlightFinderFriends.py --reanalyse "previous" "show cheapest options"
    python FlightFinderFriends.py --reanalyse "previous" "only where Charlie flies via LGW"

Claude receives the full trips digest and the user's instruction and returns:
  - A filtered / re-ranked list of trip indices (0-based into the stored trips_digest)
  - A prose explanation of what it found and why

The reanalysis never touches Google Flights — it works entirely from stored data.
"""

import json
import sys
import re
from typing import Optional

try:
    import anthropic
except ImportError:
    print("❌  Please install: pip install anthropic")
    sys.exit(1)


REANALYSE_SYSTEM = """You are a travel data analyst. The user has previously run a group flight
search and the results are stored as a JSON digest. They now want to filter, re-rank, or
explore those results in a new way — WITHOUT running a new search.

You will be given:
1. The original search query
2. The stored trips digest (JSON list of group trip combinations, each with outbound_legs,
   inbound_legs, total_price_gbp, score, arrival_spread_mins, departure_spread_mins)
3. The user's reanalysis instruction

Your job:
- Parse the user's instruction and apply it to the data
- Return a JSON object (and ONLY JSON — no prose, no markdown fences) with this shape:

{
  "indices": [0, 3, 7],          // 0-based indices into the trips array that match
  "sort_key": "total_price_gbp", // what you sorted by ("total_price_gbp", "score",
                                 //   "arrival_spread_mins", "departure_spread_mins",
                                 //   "departure_time", "arrival_time", or "original")
  "sort_ascending": true,
  "filter_description": "Trips where Charlie's return leg departs from LGW",
  "summary": "Found 4 matching trips. The cheapest is £312 with Charlie flying LGW→NAP
              outbound and LGW return, Mike via MAN. Prices range from £312–£389."
}

Filtering rules — apply common sense to the instruction:
- "cheapest" / "least expensive" → sort by total_price_gbp ascending, no filter
- "most time efficient" / "quickest" / "shortest travel time" → sort by score ascending
  (score already penalises long sync gaps); or filter to direct flights only if asked
- "only direct" / "no stops" → filter to trips where ALL legs have stops == "0"
- "Charlie returns via LGW" → filter to trips where Charlie's inbound leg destination
  is "LGW" (or origin contains "LGW" for the return leg)
- "Mike flies outbound from MAN" → filter outbound_legs for Mike with origin == "MAN"
- "arriving same day" → filter to trips where arrival_spread_mins < 120
- "tightest arrivals" → sort by arrival_spread_mins ascending
- "tightest departures" → sort by departure_spread_mins ascending
- "under £X" → filter to total_price_gbp < X

If no trips match the filter, set indices to [] and explain in summary.
If the instruction is ambiguous, apply the most reasonable interpretation and note it.
Always include all matching indices even if the list is long — the caller will truncate."""


def reanalyse(
    search_id_or_ref: str,
    instruction: str,
    api_key: str,
    top_n: int = 10,
) -> Optional[dict]:
    """
    Load a stored search, send its digest + instruction to Claude, get back
    a filtered/re-ranked view, then display it.

    Returns the reanalysis result dict, or None on failure.
    """
    from search_store import load, describe_all

    record = load(search_id_or_ref)
    if record is None:
        print(f"\n  ❌  No saved search found matching '{search_id_or_ref}'.")
        print(f"\n  Available searches:\n{describe_all()}")
        return None

    trips_digest = record.get("trips_digest")
    if not trips_digest:
        print(f"\n  ❌  Search '{record['id']}' has no stored trips digest.")
        return None

    original_query = record.get("query", "(unknown)")
    slug           = record.get("slug", "")
    searched_at    = record.get("searched_at", "")

    print(f"\n  🔍  Reanalysing search {record['id']} — {slug}")
    print(f"      Original query: {original_query}")
    print(f"      Searched at:    {searched_at}")
    print(f"      Trips stored:   {len(trips_digest)}")
    print(f"      Instruction:    {instruction}\n")

    payload = {
        "original_query":  original_query,
        "trips":           trips_digest,
        "instruction":     instruction,
    }

    try:
        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model="claude-sonnet-4-5",
            max_tokens=2048,
            system=REANALYSE_SYSTEM,
            messages=[{"role": "user", "content": json.dumps(payload, indent=2)}],
        )
        raw = msg.content[0].text.strip()
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$",       "", raw)
        result = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"  ❌  Claude returned unexpected output: {e}")
        return None
    except Exception as e:
        print(f"  ❌  Reanalysis failed: {e}")
        return None

    indices     = result.get("indices", [])
    sort_key    = result.get("sort_key", "original")
    filter_desc = result.get("filter_description", instruction)
    summary     = result.get("summary", "")

    print(f"  📋  Filter: {filter_desc}")
    print(f"  📊  Sorted by: {sort_key}")
    print(f"  ✅  {len(indices)} matching trip(s) (showing top {min(top_n, len(indices))})\n")

    if not indices:
        print(f"  🤖  {summary}\n")
        return result

    # Display the matched trips
    _display_reanalysis_trips(trips_digest, indices[:top_n], top_n)

    # Claude summary
    print(f"\n  {'═'*62}")
    print(f"  🤖  REANALYSIS SUMMARY\n  {'═'*62}")
    # Word-wrap at 70 chars
    words  = summary.split()
    line   = "  "
    for word in words:
        if len(line) + len(word) + 1 > 72:
            print(line)
            line = "  " + word
        else:
            line = line + (" " if line != "  " else "") + word
    if line.strip():
        print(line)
    print()

    return result


def _display_reanalysis_trips(trips_digest: list, indices: list, top_n: int):
    """Pretty-print the reanalysis-selected trips from the stored digest."""
    for rank, idx in enumerate(indices, 1):
        if idx >= len(trips_digest):
            continue
        t = trips_digest[idx]

        total     = t.get("total_price_gbp", 0)
        score     = t.get("score", 0)
        arr_mins  = t.get("arrival_spread_mins", -1)
        dep_mins  = t.get("departure_spread_mins", -1)
        n_legs    = len(t.get("outbound_legs", []))
        per_p     = total / n_legs if n_legs else 0

        arr_label = _spread_label(arr_mins)
        dep_label = _spread_label(dep_mins)

        print(f"  {'═'*62}")
        print(f"  #{rank} (stored #{idx+1})  💰 GBP {total:.0f}  (GBP {per_p:.0f}/person)")
        print(f"       📊 Score {score:.1f}  |  "
              f"🛬 arrival gap: {arr_label}  |  🛫 dep gap: {dep_label}")

        out_legs = t.get("outbound_legs", [])
        inb_legs = t.get("inbound_legs",  [])

        if out_legs:
            dest = out_legs[0].get("destination", "?")
            print(f"\n  ── OUTBOUND (→ {dest}) {'─'*38}")
            for leg in sorted(out_legs, key=lambda f: f.get("arrive", "") or ""):
                _print_leg(leg, role="outbound")

        if inb_legs:
            orig = inb_legs[0].get("origin", "?")
            print(f"\n  ── RETURN ({orig} →) {'─'*40}")
            for leg in sorted(inb_legs, key=lambda f: f.get("depart", "") or ""):
                _print_leg(leg, role="inbound")
        print()


def _print_leg(leg: dict, role: str = ""):
    name    = leg.get("traveller", "?")
    airline = leg.get("airline",   "?")
    orig    = leg.get("origin",    "?")
    dest    = leg.get("destination","?")
    date    = leg.get("date",       "?")
    depart  = leg.get("depart",     "?")
    arrive  = leg.get("arrive",     "?")
    price   = leg.get("price_gbp",  0)
    stops   = leg.get("stops",      "?")
    travel  = leg.get("travel_time","")

    stops_label = "✈ Direct" if str(stops) == "0" else f"↩ {stops} stop(s)"

    if role == "outbound":
        time_line = f"🛫 {depart}  →  🛬 arrives {arrive}  ◀ sync point"
    elif role == "inbound":
        time_line = f"🛫 departs {depart}  ◀ sync point  →  🛬 {arrive}"
    else:
        time_line = f"🛫 {depart}  →  🛬 {arrive}"

    indent = "      "
    print(
        f"\n{indent}👤 {name:<12}  ✈️  {airline}\n"
        f"{indent}   {orig} → {dest}   📅 {date}\n"
        f"{indent}   {time_line}   ⏱ {travel}   {stops_label}\n"
        f"{indent}   💰 GBP {price:.0f}"
    )


def _spread_label(minutes: int) -> str:
    if minutes < 0:   return "unknown"
    if minutes == 0:  return "same time ✅"
    h, m = divmod(minutes, 60)
    if h and m: return f"{h}h {m}m gap"
    if h:       return f"{h}h gap"
    return f"{m}m gap"


def list_searches():
    """Print all saved searches to stdout."""
    from search_store import describe_all
    print(f"\n  {'═'*62}")
    print(f"  📂  SAVED SEARCHES  (~/.flightfinder/searches/)")
    print(f"  {'═'*62}")
    print(describe_all())
